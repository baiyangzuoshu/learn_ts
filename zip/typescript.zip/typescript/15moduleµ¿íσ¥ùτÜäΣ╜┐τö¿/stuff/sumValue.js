"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function sumValue(num1, num2) {
    return num1 + num2;
}
exports.default = sumValue;
