"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PI = 3.14;
function calcCircle(value) {
    return value * exports.PI;
}
exports.calcCircle = calcCircle;
