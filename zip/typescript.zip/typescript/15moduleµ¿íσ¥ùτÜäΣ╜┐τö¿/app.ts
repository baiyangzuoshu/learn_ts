// 模块
// import { PI, calcCircle } from './stuff/circle';
import * as Circl from './stuff/circle';
// import { sumValue } from './stuff/sumValue';
import sum from './stuff/sumValue';
console.log(Circl.PI);
console.log(Circl.calcCircle(8));
console.log(sum(8, 120));
