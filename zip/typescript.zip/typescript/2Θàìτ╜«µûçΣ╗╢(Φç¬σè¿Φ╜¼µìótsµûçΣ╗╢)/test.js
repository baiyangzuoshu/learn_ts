"use strict";
console.log('hello ts');
