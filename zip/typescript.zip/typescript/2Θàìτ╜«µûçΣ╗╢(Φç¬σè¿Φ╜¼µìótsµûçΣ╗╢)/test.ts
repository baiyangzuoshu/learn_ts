console.log('hello ts');
